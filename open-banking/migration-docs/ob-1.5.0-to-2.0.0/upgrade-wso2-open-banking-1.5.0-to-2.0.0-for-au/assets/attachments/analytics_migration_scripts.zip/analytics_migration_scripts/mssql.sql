DECLARE @con_com as VARCHAR(8000);
SET @con_com = (SELECT name from sys.objects where parent_object_id=object_id('ApiLastAccessSummary') AND type='PK');
EXEC('ALTER TABLE ApiLastAccessSummary DROP CONSTRAINT ' + @con_com);
ALTER TABLE ApiLastAccessSummary ALTER COLUMN APIVERSION VARCHAR(254) NOT NULL;
ALTER TABLE ApiLastAccessSummary ADD PRIMARY KEY (APINAME,APICREATOR,APIVERSION,APICREATORTENANTDOMAIN);
