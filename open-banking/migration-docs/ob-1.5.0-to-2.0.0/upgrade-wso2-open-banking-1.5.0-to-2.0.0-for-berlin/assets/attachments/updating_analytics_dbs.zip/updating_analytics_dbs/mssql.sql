CREATE PROCEDURE dbo.alter_geolocation_table_if_coloumn_not_exist
AS
BEGIN
IF NOT EXISTS(
    SELECT name  FROM SYS.COLUMNS
        WHERE OBJECT_ID = OBJECT_ID('geolocationagg_seconds') AND NAME = 'agg_count')
    BEGIN
        ALTER TABLE GeoLocationAgg_SECONDS ALTER COLUMN totalCount BIGINT;
        EXEC sp_RENAME 'GeoLocationAgg_SECONDS.totalCount' , 'AGG_COUNT', 'COLUMN';
        ALTER TABLE GeoLocationAgg_MINUTES ALTER COLUMN totalCount BIGINT;
        EXEC sp_RENAME 'GeoLocationAgg_MINUTES.totalCount' , 'AGG_COUNT', 'COLUMN';
        ALTER TABLE GeoLocationAgg_HOURS ALTER COLUMN totalCount BIGINT;
        EXEC sp_RENAME 'GeoLocationAgg_HOURS.totalCount' , 'AGG_COUNT', 'COLUMN';
        ALTER TABLE GeoLocationAgg_DAYS ALTER COLUMN totalCount BIGINT;
        EXEC sp_RENAME 'GeoLocationAgg_DAYS.totalCount' , 'AGG_COUNT', 'COLUMN';
        ALTER TABLE GeoLocationAgg_MONTHS ALTER COLUMN totalCount BIGINT;
        EXEC sp_RENAME 'GeoLocationAgg_MONTHS.totalCount' , 'AGG_COUNT', 'COLUMN';
        ALTER TABLE GeoLocationAgg_YEARS ALTER COLUMN totalCount BIGINT;
        EXEC sp_RENAME 'GeoLocationAgg_YEARS.totalCount' , 'AGG_COUNT', 'COLUMN';
    END     
END

use <APIM_ANALYTICS_DB>;
EXEC dbo.alter_geolocation_table_if_coloumn_not_exist;
DROP PROCEDURE dbo.alter_geolocation_table_if_coloumn_not_exist;
